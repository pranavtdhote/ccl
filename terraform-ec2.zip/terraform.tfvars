aws_region     = "eu-north-1"
ami_id         = "ami-080254318c2d8932f"
instance_type  = "t3.micro"
key_name       = "pranav"