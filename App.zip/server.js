// server.js

// Import required modules
const express = require('express');
const path = require('path');

// Create express app
const app = express();

// AWS Beanstalk uses dynamic port
const PORT = process.env.PORT || 8080;

// Middleware: Logging requests (for debugging)
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

// Serve static files from 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Health check route (VERY IMPORTANT for Beanstalk)
app.get('/health', (req, res) => {
    res.status(200).json({ status: "OK", message: "Server is running 🚀" });
});

// API route example (for viva explanation)
app.get('/api', (req, res) => {
    res.json({
        message: "Hello from Node.js API",
        timestamp: new Date()
    });
});

// Handle 404 errors
app.use((req, res) => {
    res.status(404).send("Page Not Found");
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});